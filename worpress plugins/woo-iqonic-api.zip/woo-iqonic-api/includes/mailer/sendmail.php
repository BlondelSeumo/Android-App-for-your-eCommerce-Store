<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require IQONIC_API_DIR .'includes/mailer/vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
function iqonic_php_mailer($to,$password)
{


    $mail = new PHPMailer(true);
    global $app_opt_name;
    $iqonic_option = get_option( 'iqonic_app_options' );
    
    if(isset($iqonic_option['client_email']) && !empty($iqonic_option['client_email']))
    {
        $email = $iqonic_option['client_email'];
    }
    else
    {
        return false;
    }

    if(isset($iqonic_option['client_password']) && !empty($iqonic_option['client_password']))
    {
        $pass = $iqonic_option['client_password'];
    }
    else
    {
        return false;
    }
    if(isset($iqonic_option['client_name']) && !empty($iqonic_option['client_name']))
    {
        $mailer = $iqonic_option['client_name'];
    }
    else
    {
        $mailer = 'Admin';   
    }

    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = $email;                     // SMTP username
        $mail->Password   = $pass;                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

        //Recipients
        $mail->setFrom($email, $mailer);
        $mail->addAddress($to, 'User');     // Add a recipient
        // $mail->addAddress('ellen@example.com');               // Name is optional
        // $mail->addReplyTo('info@example.com', 'Information');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

       

        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'New Password';
        $html = '<label><b>Hello,</b></label>';
        $html.= '<p>Your recently requested to reset your password. Here is the new password for your App</p>';
        $html.='<p><b>New Password </b> : '.$password.'</p>';        
        $html.='<p>Thanks,</p>';
        $html.='<p>'.$mailer.'</p>';
        $mail->Body = $html;
        

        if($mail->send())
        {
            return true;

        }
        else
        {
            return false;
        }
        
    } catch (Exception $e) {
        return false;
    }
}


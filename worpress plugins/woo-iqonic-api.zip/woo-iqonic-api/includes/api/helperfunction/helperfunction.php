<?php



function iqonic_check_zone_location($zone, $code, $postcode = '') {
    $zone_locations = $zone['zone_locations'];

    if (count($zone_locations)) {
        $zone_check = false;
        foreach ($zone_locations as $zone) {
            if ($zone->type == 'state' && $zone->code == $code) {
                $zone_check = true;
            }
        }


        if ($zone_check) {
            foreach ($zone_locations as $location) {
                if ($postcode != '') {
                    if ($location->type == 'postcode' || $location->type == 'country') {
                        if (strpos($location->code, '*') !== false) {
                            $new_postcode = substr($postcode, 0, 4). '*';
                            if ($new_postcode == $location->code) {
                                return true;
                            }
                        } else {
                            if ($location->code == $postcode) {
                                return true;
                            }
                        }
                    } else {
                        if ($location->code == $code) {
                            return true;
                        }
                    }
                } else {
                    if ($location->code == $code) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

function iqonic_check_ip_limitation_on_shipping_method ($zone) {
    $zone_locations = $zone['zone_locations'];
    $post_codes = [];
    if (count($zone_locations)) {
        foreach ($zone_locations as $location) {
            if ($location->type == 'postcode') {
                array_push($post_codes, $location->code);
            }
        }
    }
    return $post_codes;
}


function iqonic_title_filter( $where, $wp_query ){
    global $wpdb;
    if( $search_term = $wp_query->get( 'iqonic_title_filter' ) ) :
        $search_term = $wpdb->esc_like( $search_term );
        $search_term = ' \'%' . $search_term . '%\'';
        $title_filter_relation = ( strtoupper( $wp_query->get( 'title_filter_relation' ) ) == 'OR' ? 'OR' : 'AND' );
        $where .= ' '.$title_filter_relation.' ' . $wpdb->posts . '.post_title LIKE ' . $search_term;
    endif;
    return $where;
}

add_filter( 'posts_where', 'iqonic_title_filter', 10, 2 );


function iqonic_get_images_link($id)
{
    global $product;
    $array = array();
    $img = array();
    $product = wc_get_product($id);
    $thumb = wp_get_attachment_image_src($product->get_image_id() , "thumbnail");
    $full = wp_get_attachment_image_src($product->get_image_id() , "full");
        $img[] = $thumb[0];
        $img[] = $full[0];
        //return $array;


        $gallery = array();
        foreach ($product->get_gallery_image_ids() as $img_id)
        {
            $g = wp_get_attachment_image_src($img_id, "full");
            $gallery[] = $g[0];
        }
        $array['image'] = $img;
        $array['gallery'] = $gallery;
        return $array;
}

function iqonic_get_special_product_details_helper ($type)
{
	$product = [];
	global $wpdb;

	$product_meta = $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key = '{$type}' AND  meta_value = 'yes' LIMIT 10", object);

	if (count($product_meta)) {

		foreach ($product_meta as $meta) {
			$data = iqonic_get_product_details_helper($meta->post_id);
			if ($data != []) {
				$product[] = $data;
			}
		}
	}

	return $product;
}

function iqonic_get_product_details_helper ($product_id)
{
	global $product;
	$product = wc_get_product($product_id);

	if ($product === false) {
		return [];
	}

	$temp = array(
		'id'                    => $product->get_id(),
		'name'                  => $product->get_name(),
		'slug'                  => $product->get_slug(),
		'permalink'             => $product->get_permalink(),
		'date_created'          => wc_rest_prepare_date_response( $product->get_date_created() ),
		'date_modified'         => wc_rest_prepare_date_response( $product->get_date_modified() ),
		'type'                  => $product->get_type(),
		'status'                => $product->get_status(),
		'featured'              => $product->is_featured(),
		'catalog_visibility'    => $product->get_catalog_visibility(),
		'description'           => wpautop( do_shortcode( $product->get_description() ) ),
		'short_description'     => apply_filters( 'woocommerce_short_description', $product->get_short_description() ),
		'sku'                   => $product->get_sku(),
		'price'                 => $product->get_price(),
		'regular_price'         => $product->get_regular_price(),
		'sale_price'            => $product->get_sale_price() ? $product->get_sale_price() : '',
		'date_on_sale_from'     => $product->get_date_on_sale_from() ? date( 'Y-m-d', $product->get_date_on_sale_from()->getTimestamp() ) : '',
		'date_on_sale_to'       => $product->get_date_on_sale_to() ? date( 'Y-m-d', $product->get_date_on_sale_to()->getTimestamp() ) : '',
		'price_html'            => $product->get_price_html(),
		'on_sale'               => $product->is_on_sale(),
		'purchasable'           => $product->is_purchasable(),
		'total_sales'           => $product->get_total_sales(),
		'virtual'               => $product->is_virtual(),
		'downloadable'          => $product->is_downloadable(),
		'downloads'             => iqonic_get_product_downloads( $product ),
		'download_limit'        => $product->get_download_limit(),
		'download_expiry'       => $product->get_download_expiry(),
		'download_type'         => 'standard',
		'external_url'          => $product->is_type( 'external' ) ? $product->get_product_url() : '',
		'button_text'           => $product->is_type( 'external' ) ? $product->get_button_text() : '',
		'tax_status'            => $product->get_tax_status(),
		'tax_class'             => $product->get_tax_class(),
		'manage_stock'          => $product->managing_stock(),
		'stock_quantity'        => $product->get_stock_quantity(),
		'in_stock'              => $product->is_in_stock(),
		'backorders'            => $product->get_backorders(),
		'backorders_allowed'    => $product->backorders_allowed(),
		'backordered'           => $product->is_on_backorder(),
		'sold_individually'     => $product->is_sold_individually(),
		'weight'                => $product->get_weight(),
		'dimensions'            => array(
			'length' => $product->get_length(),
			'width'  => $product->get_width(),
			'height' => $product->get_height(),
		),
		'shipping_required'     => $product->needs_shipping(),
		'shipping_taxable'      => $product->is_shipping_taxable(),
		'shipping_class'        => $product->get_shipping_class(),
		'shipping_class_id'     => $product->get_shipping_class_id(),
		'reviews_allowed'       => $product->get_reviews_allowed(),
		'average_rating'        => wc_format_decimal( $product->get_average_rating(), 2 ),
		'rating_count'          => $product->get_rating_count(),
		'related_ids'           => array_map( 'absint', array_values( wc_get_related_products( $product->get_id() ) ) ),
		'upsell_ids'            => array_map( 'absint', $product->get_upsell_ids() ),
		'cross_sell_ids'        => array_map( 'absint', $product->get_cross_sell_ids() ),
		'parent_id'             => $product->get_parent_id(),
		'purchase_note'         => wpautop( do_shortcode( wp_kses_post( $product->get_purchase_note() ) ) ),
		'categories'            => iqonic_get_taxonomy_terms_helper( $product ),
		'tags'                  => iqonic_get_taxonomy_terms_helper( $product, 'tag' ),
		'images'                => iqonic_get_product_images_helper( $product ),
		'attributes'            => iqonic_get_product_attributes( $product ),
		'default_attributes'    => iqonic_get_product_default_attributes( $product ),
		'variations'            => $product->get_children(),
		'grouped_products'      => array(),
		'upsell_id'      => array(),
		'menu_order'            => $product->get_menu_order(),

	);

	if (isset($temp['upsell_ids']) && count($temp['upsell_ids'])) {
		$upsell_products = [];

		foreach ($temp['upsell_ids'] as $key => $p_id) {

			$upsell_product = wc_get_product($p_id);

			if ($upsell_product != null) {
				$upsell_products[$key] = [
					'id'                    => $upsell_product->get_id(),
					'name'                  => $upsell_product->get_name(),
					'slug'                  => $upsell_product->get_slug(),
					'price'                 => $upsell_product->get_price(),
					'regular_price'         => $upsell_product->get_regular_price(),
					'sale_price'            => $upsell_product->get_sale_price() ? $upsell_product->get_sale_price() : '',
					'images'                => iqonic_get_product_images_helper( $upsell_product ),
				];
			}
		}

		if (count($upsell_products)) {
			$temp['upsell_id'] = $upsell_products;
		}
	}

	return $temp;

}

function iqonic_get_product_variation_id( $product )
{

}

function iqonic_get_product_downloads( $product ) {
	$downloads = array();

	if ( $product->is_downloadable() ) {
		foreach ( $product->get_downloads() as $file_id => $file ) {
			$downloads[] = array(
				'id'   => $file_id, // MD5 hash.
				'name' => $file['name'],
				'file' => $file['file'],
			);
		}
	}

	return $downloads;
}

function iqonic_get_taxonomy_terms_helper( $product, $taxonomy = 'cat' ) {
	$terms = array();

	foreach ( wc_get_object_terms( $product->get_id(), 'product_' . $taxonomy ) as $term ) {
		$terms[] = array(
			'id'   => $term->term_id,
			'name' => $term->name,
			'slug' => $term->slug,
		);
	}

	return $terms;
}

function iqonic_get_product_images_helper( $product ) {
	$images = array();
	$attachment_ids = array();

	// Add featured image.
	if ( $product->get_image_id() ) {
		$attachment_ids[] = $product->get_image_id();
	}

	$attachment_ids = array_merge( $attachment_ids, $product->get_gallery_image_ids() );

	foreach ( $attachment_ids as $position => $attachment_id ) {
		$attachment_post = get_post( $attachment_id );
		if ( is_null( $attachment_post ) ) {
			continue;
		}

		$attachment = wp_get_attachment_image_src( $attachment_id, 'full' );
		if ( ! is_array( $attachment ) ) {
			continue;
		}

		$images[] = array(
			'id'            => (int) $attachment_id,
			'date_created'  => wc_rest_prepare_date_response( $attachment_post->post_date_gmt ),
			'date_modified' => wc_rest_prepare_date_response( $attachment_post->post_modified_gmt ),
			'src'           => current( $attachment ),
			'name'          => get_the_title( $attachment_id ),
			'alt'           => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
			'position'      => (int) $position,
		);
	}

	if ( empty( $images ) ) {
		$images[] = array(
			'id'            => 0,
			'date_created'  => wc_rest_prepare_date_response( current_time( 'mysql' ) ), // Default to now.
			'date_modified' => wc_rest_prepare_date_response( current_time( 'mysql' ) ),
			'src'           => wc_placeholder_img_src(),
			'name'          => __( 'Placeholder', 'woocommerce' ),
			'alt'           => __( 'Placeholder', 'woocommerce' ),
			'position'      => 0,
		);
	}

	return $images;
}

function iqonic_get_product_attributes( $product ) {
	$attributes = array();

	if ( $product->is_type( 'variation' ) ) {
		// Variation attributes.
		foreach ( $product->get_variation_attributes() as $attribute_name => $attribute ) {
			$name = str_replace( 'attribute_', '', $attribute_name );

			if ( ! $attribute ) {
				continue;
			}

			// Taxonomy-based attributes are prefixed with `pa_`, otherwise simply `attribute_`.
			if ( 0 === strpos( $attribute_name, 'attribute_pa_' ) ) {
				$option_term = get_term_by( 'slug', $attribute, $name );
				$attributes[] = array(
					'id'     => wc_attribute_taxonomy_id_by_name( $name ),
					'name'   => iqonic_get_product_attribute_taxonomy_label( $name ),
					'option' => $option_term && ! is_wp_error( $option_term ) ? $option_term->name : $attribute,
				);
			} else {
				$attributes[] = array(
					'id'     => 0,
					'name'   => $name,
					'option' => $attribute,
				);
			}
		}
	} else {
		foreach ( $product->get_attributes() as $attribute ) {
			if ( $attribute['is_taxonomy'] ) {
				$attributes[] = array(
					'id'        => wc_attribute_taxonomy_id_by_name( $attribute['name'] ),
					'name'      => iqonic_get_product_attribute_taxonomy_label( $attribute['name'] ),
					'position'  => (int) $attribute['position'],
					'visible'   => (bool) $attribute['is_visible'],
					'variation' => (bool) $attribute['is_variation'],
					'options'   => iqonic_get_product_attribute_options( $product->get_id(), $attribute ),
				);
			} else {
				$attributes[] = array(
					'id'        => 0,
					'name'      => $attribute['name'],
					'position'  => (int) $attribute['position'],
					'visible'   => (bool) $attribute['is_visible'],
					'variation' => (bool) $attribute['is_variation'],
					'options'   => iqonic_get_product_attribute_options( $product->get_id(), $attribute ),
				);
			}
		}
	}

	return $attributes;
}

function iqonic_get_product_attribute_taxonomy_label( $name ) {
	$tax    = get_taxonomy( $name );
	$labels = get_taxonomy_labels( $tax );

	return $labels->singular_name;
}


function iqonic_get_product_attribute_options( $product_id, $attribute ) {
	if ( isset( $attribute['is_taxonomy'] ) && $attribute['is_taxonomy'] ) {
		return wc_get_product_terms( $product_id, $attribute['name'], array( 'fields' => 'names' ) );
	} elseif ( isset( $attribute['value'] ) ) {
		return array_map( 'trim', explode( '|', $attribute['value'] ) );
	}

	return array();
}

function iqonic_get_product_default_attributes( $product ) {
	$default = array();

	if ( $product->is_type( 'variable' ) ) {
		foreach ( array_filter( (array) $product->get_default_attributes(), 'strlen' ) as $key => $value ) {
			if ( 0 === strpos( $key, 'pa_' ) ) {
				$default[] = array(
					'id'     => wc_attribute_taxonomy_id_by_name( $key ),
					'name'   => iqonic_get_product_attribute_taxonomy_label( $key ),
					'option' => $value,
				);
			} else {
				$default[] = array(
					'id'     => 0,
					'name'   => wc_attribute_taxonomy_slug( $key ),
					'option' => $value,
				);
			}
		}
	}

	return $default;
}

function iqonic_get_date_timestamp_helper($date)
{
	$new_date = null;

	if ($date != null) {
		$new_date = gmdate( 'Y-m-d H:i:s', $date->getTimestamp());
	}

	return $new_date;
}
function iqonic_get_product_helper($id,$num_pages = '',$i='')
{
		global $product;
		$product = wc_get_product($id);
        $array['num_pages'] = $num_pages;
        $array['srno'] = $i;
        
        $array['pro_id'] = $product->get_id();
        $array['categories'] = $product->get_category_ids();

        $array['name'] = $product->get_name();

        $array['type'] = $product->get_type();
        $array['slug'] = $product->get_slug();
        $array['date_created'] = $product->get_date_created();
        $array['date_modified'] = $product->get_date_modified();
        $array['status'] = $product->get_status();
        $array['featured'] = $product->get_featured();
        $array['catalog_visibility'] = $product->get_catalog_visibility();
        $array['description'] = $product->get_description();
        $array['short_description'] = $product->get_short_description();
        $array['sku'] = $product->get_sku();

        $array['virtual'] = $product->get_virtual();
        $array['permalink'] = get_permalink($product->get_id());
        $array['price'] = $product->get_price();
        $array['regular_price'] = $product->get_regular_price();
        $array['sale_price'] = $product->get_sale_price();
        $array['brand'] = $product->get_attribute('brand');
        $array['size'] = $product->get_attribute('size');
        $array['color'] = $product->get_attribute('color');
        
        $array['weight_attribute'] = $product->get_attribute('weight');

        $array['tax_status'] = $product->get_tax_status();
        $array['tax_class'] = $product->get_tax_class();
        $array['manage_stock'] = $product->get_manage_stock();
        $array['stock_quantity'] = $product->get_stock_quantity();
        $array['stock_status'] = $product->get_stock_status();
        $array['backorders'] = $product->get_backorders();
        $array['sold_individually'] = $product->get_sold_individually();
        $array['get_purchase_note'] = $product->get_purchase_note();
        $array['shipping_class_id'] = $product->get_shipping_class_id();

        $array['weight'] = $product->get_weight();
        $array['length'] = $product->get_length();
        $array['width'] = $product->get_width();
        $array['height'] = $product->get_height();
        $array['dimensions'] = html_entity_decode($product->get_dimensions());

        // Get Linked Products
        $array['upsell_ids'] = $product->get_upsell_ids();
        $array['cross_sell_ids'] = $product->get_cross_sell_ids();
        $array['parent_id'] = $product->get_parent_id();

        $array['reviews_allowed'] = $product->get_reviews_allowed();
        $array['rating_counts'] = $product->get_rating_counts();
        $array['average_rating'] = $product->get_average_rating();
        $array['review_count'] = $product->get_review_count();

        $thumb = wp_get_attachment_image_src($product->get_image_id() , "thumbnail");
        $full = wp_get_attachment_image_src($product->get_image_id() , "full");
        $array['thumbnail'] = $thumb[0];
        $array['full'] = $full[0];
        $gallery = array();
        foreach ($product->get_gallery_image_ids() as $img_id)
        {
            $g = wp_get_attachment_image_src($img_id, "full");
            $gallery[] = $g[0];
        }
        $array['gallery'] = $gallery;
        $gallery = array();

        
        return $array;


}

function iqonic_throw_error($msg)
{
     $response = new WP_REST_Response(array(
        "code" => "Error",
        "message" => $msg,
        "data" => array(
            "status" => 404
        )
    )
);
    $response->set_status(404);
    return $response;
}

function allow_payment_without_login( $allcaps, $caps, $args ) {
    // Check we are looking at the WooCommerce Pay For Order Page
    if ( !isset( $caps[0] ) || $caps[0] != 'pay_for_order' )
        return $allcaps;
    // Check that a Key is provided
    if ( !isset( $_GET['key'] ) )
        return $allcaps;

    // Find the Related Order
    $order = wc_get_order( $args[2] );
    if( !$order )
        return $allcaps; # Invalid Order

    // Get the Order Key from the WooCommerce Order
    $order_key = $order->get_order_key();
    // Get the Order Key from the URL Query String
    $order_key_check = $_GET['key'];

    // Set the Permission to TRUE if the Order Keys Match
    $allcaps['pay_for_order'] = ( $order_key == $order_key_check );

    return $allcaps;
}
add_filter( 'user_has_cap', 'allow_payment_without_login', 10, 3 );

function get_enable_category($arr)
{
    $a = (array) $arr;   

    $term_meta = get_option("enable_" . $a['term_id']);

    if(!empty($term_meta['enable']))
    {
        return $a;
    }
    
}

function get_category_child($arr)
{
    $a = (array) $arr;
    if($a)
    {
        $child_terms_ids = get_term_children( $a['term_id'], 'product_cat' );
        
        $temp = array_map('get_enable_subcategory',$child_terms_ids);

        // $temp = array_filter($temp,function($var)
        // {
        //     return $var !== null;
        // });
        
        $a['subcategory'] = iqonic_filter_array($temp);    
        
        return $a;
    }
}

function iqonic_attach_category_image($arr)
{
    $a = (array) $arr;
    if($a)
    {
        $thumb_id = get_woocommerce_term_meta( $a['term_id'], 'thumbnail_id', true );
        $term_img = wp_get_attachment_url(  $thumb_id );

        if($term_img)
        {
            $a['image'] = $term_img;    
        }
        else
        {
            $a['image'] = "";       
        }
        return $a;
    }
}

function get_enable_subcategory($arr)
{
    $a = (array) $arr;
    foreach($a as $val)
    {
        $term_meta = get_option("enable_" . $val);
        if($term_meta)
        {
            return $val;
        }
    }
}

function iqonic_filter_array($arr)
{
    $res = array();
    foreach($arr as $key=>$val)
    {
        if($val != null)
        {
            array_push($res,$val);
        }
    }
    return $res;

}
?>